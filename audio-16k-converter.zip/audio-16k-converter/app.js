(function (root) {
  "use strict";

  const AUDIO_EXTENSIONS = new Set([
    "aac",
    "aiff",
    "aif",
    "amr",
    "flac",
    "m4a",
    "m4b",
    "mp3",
    "oga",
    "ogg",
    "opus",
    "wav",
    "webm",
    "wma"
  ]);

  const FFMPEG_PACKAGE_URL = "https://cdn.jsdelivr.net/npm/@ffmpeg/ffmpeg@0.12.10/dist/esm/index.js";
  const FFMPEG_UTIL_URL = "https://cdn.jsdelivr.net/npm/@ffmpeg/util@0.12.1/dist/esm/index.js";
  const FFMPEG_CORE_BASE_URL = "https://cdn.jsdelivr.net/npm/@ffmpeg/core@0.12.10/dist/umd";
  const JSZIP_URL = "https://cdn.jsdelivr.net/npm/jszip@3.10.1/+esm";

  const DEFAULT_SETTINGS = {
    sampleRate: "16000",
    channelMode: "mono",
    format: "wav"
  };

  const SAMPLE_RATES = {
    "8000": { label: "8 kHz", token: "8k" },
    "16000": { label: "16 kHz", token: "16k" },
    "22050": { label: "22.05 kHz", token: "22050hz" },
    "24000": { label: "24 kHz", token: "24k" },
    "44100": { label: "44.1 kHz", token: "44k" },
    "48000": { label: "48 kHz", token: "48k" }
  };

  const CHANNEL_MODES = {
    mono: { label: "单声道", token: "mono", ffmpegValue: "1" },
    stereo: { label: "双声道", token: "stereo", ffmpegValue: "2" },
    keep: { label: "保持原声道", token: "keep", ffmpegValue: "" }
  };

  const OUTPUT_FORMATS = {
    wav: {
      label: "WAV PCM 16-bit",
      extension: "wav",
      mimeType: "audio/wav",
      codecArgs: ["-c:a", "pcm_s16le"]
    },
    mp3: {
      label: "MP3",
      extension: "mp3",
      mimeType: "audio/mpeg",
      codecArgs: ["-c:a", "libmp3lame", "-b:a", "128k"]
    },
    m4a: {
      label: "M4A AAC",
      extension: "m4a",
      mimeType: "audio/mp4",
      codecArgs: ["-c:a", "aac", "-b:a", "128k"]
    },
    flac: {
      label: "FLAC",
      extension: "flac",
      mimeType: "audio/flac",
      codecArgs: ["-c:a", "flac"]
    },
    opus: {
      label: "OGG Opus",
      extension: "opus.ogg",
      mimeType: "audio/ogg",
      codecArgs: ["-c:a", "libopus", "-b:a", "96k"]
    }
  };

  function getExtension(fileName) {
    const cleanName = String(fileName || "").trim();
    const dotIndex = cleanName.lastIndexOf(".");
    if (dotIndex < 0 || dotIndex === cleanName.length - 1) return "";
    return cleanName.slice(dotIndex + 1).toLowerCase();
  }

  function stripFinalExtension(fileName) {
    const cleanName = String(fileName || "audio").trim() || "audio";
    const dotIndex = cleanName.lastIndexOf(".");
    if (dotIndex <= 0) return cleanName;
    return cleanName.slice(0, dotIndex);
  }

  function sanitizeBaseName(fileName) {
    const base = stripFinalExtension(fileName)
      .replace(/[\\/:*?"<>|]+/g, "_")
      .replace(/\s+/g, " ")
      .trim();
    return base || "audio";
  }

  function normalizeSettings(settings) {
    const input = settings || {};
    const sampleRate = SAMPLE_RATES[input.sampleRate] ? input.sampleRate : DEFAULT_SETTINGS.sampleRate;
    const channelMode = CHANNEL_MODES[input.channelMode] ? input.channelMode : DEFAULT_SETTINGS.channelMode;
    const format = OUTPUT_FORMATS[input.format] ? input.format : DEFAULT_SETTINGS.format;
    return { sampleRate, channelMode, format };
  }

  function getFormatConfig(format) {
    return OUTPUT_FORMATS[format] || OUTPUT_FORMATS[DEFAULT_SETTINGS.format];
  }

  function getSampleRateConfig(sampleRate) {
    return SAMPLE_RATES[sampleRate] || SAMPLE_RATES[DEFAULT_SETTINGS.sampleRate];
  }

  function getChannelConfig(channelMode) {
    return CHANNEL_MODES[channelMode] || CHANNEL_MODES[DEFAULT_SETTINGS.channelMode];
  }

  function describeSettings(settings) {
    const normalized = normalizeSettings(settings);
    return `${getSampleRateConfig(normalized.sampleRate).label} · ${getChannelConfig(normalized.channelMode).label} · ${getFormatConfig(normalized.format).label}`;
  }

  function makeOutputName(fileName, settings) {
    const normalized = normalizeSettings(settings);
    const sampleToken = getSampleRateConfig(normalized.sampleRate).token;
    const channelToken = getChannelConfig(normalized.channelMode).token;
    const extension = getFormatConfig(normalized.format).extension;
    return `${sanitizeBaseName(fileName)}_${sampleToken}_${channelToken}.${extension}`;
  }

  function buildFFmpegArgs(inputName, outputName, settings) {
    const normalized = normalizeSettings(settings);
    const channelConfig = getChannelConfig(normalized.channelMode);
    const formatConfig = getFormatConfig(normalized.format);
    const args = ["-hide_banner", "-i", inputName, "-vn"];
    if (channelConfig.ffmpegValue) {
      args.push("-ac", channelConfig.ffmpegValue);
    }
    args.push("-ar", normalized.sampleRate, ...formatConfig.codecArgs, outputName);
    return args;
  }

  function makeUniqueName(fileName, usedNames) {
    if (!usedNames || !usedNames.has(fileName)) return fileName;
    const dotIndex = fileName.lastIndexOf(".");
    const stem = dotIndex > 0 ? fileName.slice(0, dotIndex) : fileName;
    const extension = dotIndex > 0 ? fileName.slice(dotIndex) : "";
    let index = 2;
    let candidate = `${stem}-${index}${extension}`;
    while (usedNames.has(candidate)) {
      index += 1;
      candidate = `${stem}-${index}${extension}`;
    }
    return candidate;
  }

  function isAudioFile(file) {
    if (!file) return false;
    if (file.type && file.type.toLowerCase().startsWith("audio/")) return true;
    return AUDIO_EXTENSIONS.has(getExtension(file.name));
  }

  function formatBytes(bytes) {
    const value = Number(bytes) || 0;
    if (value < 1024) return `${value} B`;
    const units = ["KB", "MB", "GB"];
    let size = value / 1024;
    let unitIndex = 0;
    while (size >= 1024 && unitIndex < units.length - 1) {
      size /= 1024;
      unitIndex += 1;
    }
    const rounded = size >= 10 || Number.isInteger(size) ? Math.round(size) : Math.round(size * 10) / 10;
    return `${rounded} ${units[unitIndex]}`;
  }

  function escapeHtml(value) {
    return String(value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  const exported = {
    buildFFmpegArgs,
    describeSettings,
    formatBytes,
    getExtension,
    getFormatConfig,
    isAudioFile,
    makeOutputName,
    makeUniqueName,
    normalizeSettings,
    sanitizeBaseName
  };

  if (typeof module !== "undefined" && module.exports) {
    module.exports = exported;
  }

  root.Audio16kConverter = exported;

  if (!root.document) return;

  const state = {
    activeJob: null,
    ffmpeg: null,
    fetchFile: null,
    isConverting: false,
    isLoadingEngine: false,
    isZipping: false,
    globalSettings: { ...DEFAULT_SETTINGS },
    jobs: [],
    nextId: 1,
    usedOutputNames: new Set()
  };

  const statusText = {
    done: "完成",
    error: "失败",
    loading: "加载",
    pending: "等待",
    processing: "转换中"
  };

  const elements = {};

  function init() {
    elements.fileInput = document.getElementById("file-input");
    elements.dropZone = document.getElementById("drop-zone");
    elements.globalSampleRate = document.getElementById("global-sample-rate");
    elements.globalChannelMode = document.getElementById("global-channel-mode");
    elements.globalFormat = document.getElementById("global-format");
    elements.applySettings = document.getElementById("apply-settings");
    elements.convertAll = document.getElementById("convert-all");
    elements.downloadAll = document.getElementById("download-all");
    elements.clearAll = document.getElementById("clear-all");
    elements.summaryCount = document.getElementById("summary-count");
    elements.summarySize = document.getElementById("summary-size");
    elements.globalStatus = document.getElementById("global-status");
    elements.queueProgress = document.getElementById("queue-progress");
    elements.queueList = document.getElementById("queue-list");
    elements.emptyState = document.getElementById("empty-state");
    elements.targetSampleRate = document.getElementById("target-sample-rate");
    elements.targetChannel = document.getElementById("target-channel");
    elements.targetFormat = document.getElementById("target-format");

    elements.fileInput.addEventListener("change", (event) => {
      addFiles(Array.from(event.target.files || []));
      elements.fileInput.value = "";
    });

    elements.dropZone.addEventListener("dragover", handleDragOver);
    elements.dropZone.addEventListener("dragleave", handleDragLeave);
    elements.dropZone.addEventListener("drop", handleDrop);
    elements.globalSampleRate.addEventListener("change", handleGlobalSettingsChange);
    elements.globalChannelMode.addEventListener("change", handleGlobalSettingsChange);
    elements.globalFormat.addEventListener("change", handleGlobalSettingsChange);
    elements.applySettings.addEventListener("click", applyGlobalSettingsToQueue);
    elements.convertAll.addEventListener("click", convertAll);
    elements.downloadAll.addEventListener("click", downloadAll);
    elements.clearAll.addEventListener("click", clearAll);
    elements.queueList.addEventListener("click", handleQueueClick);
    elements.queueList.addEventListener("change", handleQueueChange);

    syncGlobalControls();
    render();
  }

  function handleDragOver(event) {
    event.preventDefault();
    elements.dropZone.classList.add("is-dragging");
  }

  function handleDragLeave(event) {
    if (!elements.dropZone.contains(event.relatedTarget)) {
      elements.dropZone.classList.remove("is-dragging");
    }
  }

  function handleDrop(event) {
    event.preventDefault();
    elements.dropZone.classList.remove("is-dragging");
    addFiles(Array.from(event.dataTransfer.files || []));
  }

  function syncGlobalControls() {
    elements.globalSampleRate.value = state.globalSettings.sampleRate;
    elements.globalChannelMode.value = state.globalSettings.channelMode;
    elements.globalFormat.value = state.globalSettings.format;
  }

  function readGlobalSettings() {
    return normalizeSettings({
      sampleRate: elements.globalSampleRate.value,
      channelMode: elements.globalChannelMode.value,
      format: elements.globalFormat.value
    });
  }

  function handleGlobalSettingsChange() {
    state.globalSettings = readGlobalSettings();
    setGlobalStatus("默认输出设置已更新；新加入的文件会使用这组参数。");
    render();
  }

  function applyGlobalSettingsToQueue() {
    if (state.isConverting || !state.jobs.length) return;
    state.globalSettings = readGlobalSettings();
    for (const job of state.jobs) {
      applySettingsToJob(job, state.globalSettings);
    }
    refreshOutputNames();
    setGlobalStatus("已把统一输出设置应用到队列里的所有文件。");
    render();
  }

  function addFiles(files) {
    let accepted = 0;
    let skipped = 0;

    for (const file of files) {
      if (!isAudioFile(file)) {
        skipped += 1;
        continue;
      }
      const settings = { ...state.globalSettings };
      const outputName = reserveOutputName(makeOutputName(file.name, settings));
      state.jobs.push({
        error: "",
        file,
        id: state.nextId,
        outputBlob: null,
        outputName,
        outputUrl: "",
        progress: 0,
        settings,
        status: "pending"
      });
      state.nextId += 1;
      accepted += 1;
    }

    if (accepted && skipped) {
      setGlobalStatus(`已加入 ${accepted} 个音频文件，跳过 ${skipped} 个非音频文件。`);
    } else if (accepted) {
      setGlobalStatus(`已加入 ${accepted} 个音频文件。`);
    } else if (skipped) {
      setGlobalStatus(`没有可转换的音频文件，已跳过 ${skipped} 个文件。`);
    }

    render();
  }

  function reserveOutputName(fileName) {
    const uniqueName = makeUniqueName(fileName, state.usedOutputNames);
    state.usedOutputNames.add(uniqueName);
    return uniqueName;
  }

  function rebuildUsedOutputNames() {
    state.usedOutputNames = new Set(state.jobs.map((job) => job.outputName));
  }

  function refreshOutputNames() {
    const usedNames = new Set();
    for (const job of state.jobs) {
      const outputName = makeUniqueName(makeOutputName(job.file.name, job.settings), usedNames);
      usedNames.add(outputName);
      job.outputName = outputName;
    }
    state.usedOutputNames = usedNames;
  }

  function applySettingsToJob(job, settings) {
    if (!job || state.activeJob === job) return;
    job.settings = normalizeSettings(settings);
    if (job.status === "done" || job.outputBlob || job.outputUrl) {
      revokeJobUrl(job);
    }
    if (job.status !== "processing") {
      job.status = "pending";
      job.progress = 0;
      job.error = "设置已更新，等待转换";
    }
  }

  async function ensureFFmpeg() {
    if (state.ffmpeg) return state.ffmpeg;
    if (state.isLoadingEngine) {
      while (state.isLoadingEngine) {
        await new Promise((resolve) => setTimeout(resolve, 100));
      }
      return state.ffmpeg;
    }

    state.isLoadingEngine = true;
    setGlobalStatus("正在加载 ffmpeg.wasm，首次使用需要一些时间。");
    render();

    try {
      const [{ FFmpeg }, { fetchFile, toBlobURL }] = await Promise.all([
        import(FFMPEG_PACKAGE_URL),
        import(FFMPEG_UTIL_URL)
      ]);

      const ffmpeg = new FFmpeg();
      ffmpeg.on("progress", ({ progress }) => {
        if (!state.activeJob || state.activeJob.status !== "processing") return;
        const percent = Math.max(3, Math.min(98, Math.round((progress || 0) * 100)));
        state.activeJob.progress = percent;
        renderJob(state.activeJob);
      });

      ffmpeg.on("log", ({ message }) => {
        if (!state.activeJob || !message) return;
        const compactMessage = message.length > 120 ? `${message.slice(0, 117)}...` : message;
        state.activeJob.error = compactMessage;
        renderJob(state.activeJob);
      });

      await ffmpeg.load({
        coreURL: await toBlobURL(`${FFMPEG_CORE_BASE_URL}/ffmpeg-core.js`, "text/javascript"),
        wasmURL: await toBlobURL(`${FFMPEG_CORE_BASE_URL}/ffmpeg-core.wasm`, "application/wasm")
      });

      state.ffmpeg = ffmpeg;
      state.fetchFile = fetchFile;
      setGlobalStatus("ffmpeg.wasm 已就绪。");
      return ffmpeg;
    } catch (error) {
      setGlobalStatus(`ffmpeg.wasm 加载失败：${getErrorMessage(error)}`);
      throw error;
    } finally {
      state.isLoadingEngine = false;
      render();
    }
  }

  async function convertAll() {
    if (state.isConverting) return;
    const queue = state.jobs.filter((job) => job.status === "pending" || job.status === "error");
    if (!queue.length) return;

    state.isConverting = true;
    setGlobalStatus("开始批量转换。");
    render();

    try {
      await ensureFFmpeg();
      for (const job of queue) {
        if (!state.jobs.includes(job)) continue;
        await convertJob(job);
      }
      const failedCount = state.jobs.filter((job) => job.status === "error").length;
      if (failedCount) {
        setGlobalStatus(`转换结束，${failedCount} 个文件失败。`);
      } else {
        setGlobalStatus("转换完成，可以下载。");
      }
    } finally {
      state.isConverting = false;
      state.activeJob = null;
      render();
    }
  }

  async function convertJob(job) {
    const ffmpeg = state.ffmpeg;
    const extension = getExtension(job.file.name) || "audio";
    const inputName = `input-${job.id}.${extension}`;
    const settings = normalizeSettings(job.settings);
    const formatConfig = getFormatConfig(settings.format);
    const outputName = `output-${job.id}.${formatConfig.extension}`;

    revokeJobUrl(job);
    job.status = "processing";
    job.progress = 3;
    job.error = "读取文件";
    state.activeJob = job;
    render();

    try {
      await ffmpeg.writeFile(inputName, await state.fetchFile(job.file));
      job.error = `转换为 ${describeSettings(settings)}`;
      renderJob(job);
      await ffmpeg.exec(buildFFmpegArgs(inputName, outputName, settings));
      const data = await ffmpeg.readFile(outputName);
      job.outputBlob = new Blob([data], { type: formatConfig.mimeType });
      job.outputUrl = URL.createObjectURL(job.outputBlob);
      job.progress = 100;
      job.status = "done";
      job.error = `${formatBytes(job.outputBlob.size)} 已生成`;
    } catch (error) {
      job.status = "error";
      job.progress = 0;
      job.error = getErrorMessage(error);
    } finally {
      await Promise.allSettled([ffmpeg.deleteFile(inputName), ffmpeg.deleteFile(outputName)]);
      render();
    }
  }

  async function downloadAll() {
    const completed = state.jobs.filter((job) => job.status === "done" && job.outputBlob);
    if (!completed.length || state.isZipping) return;
    if (completed.length === 1) {
      downloadJob(completed[0]);
      return;
    }

    state.isZipping = true;
    setGlobalStatus("正在打包 ZIP。");
    render();

    try {
      const { default: JSZip } = await import(JSZIP_URL);
      const zip = new JSZip();
      const usedNames = new Set();
      for (const job of completed) {
        const zipName = makeUniqueName(job.outputName, usedNames);
        usedNames.add(zipName);
        zip.file(zipName, job.outputBlob);
      }
      const zipBlob = await zip.generateAsync({ type: "blob" }, (metadata) => {
        setGlobalStatus(`正在打包 ZIP：${Math.round(metadata.percent)}%`);
      });
      triggerDownload(URL.createObjectURL(zipBlob), "converted-audio.zip", true);
      setGlobalStatus("ZIP 已生成。");
    } catch (error) {
      setGlobalStatus(`打包失败：${getErrorMessage(error)}`);
    } finally {
      state.isZipping = false;
      render();
    }
  }

  function downloadJob(job) {
    if (!job.outputUrl) return;
    triggerDownload(job.outputUrl, job.outputName, false);
  }

  function triggerDownload(url, fileName, revokeAfterDownload) {
    const link = document.createElement("a");
    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    link.remove();
    if (revokeAfterDownload) {
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    }
  }

  function clearAll() {
    if (state.isConverting) return;
    for (const job of state.jobs) revokeJobUrl(job);
    state.jobs = [];
    state.nextId = 1;
    state.usedOutputNames.clear();
    setGlobalStatus("已清空。");
    render();
  }

  function removeJob(job) {
    if (!job || state.activeJob === job) return;
    revokeJobUrl(job);
    state.jobs = state.jobs.filter((item) => item !== job);
    rebuildUsedOutputNames();
    render();
  }

  function retryJob(job) {
    if (!job || state.isConverting) return;
    job.status = "pending";
    job.progress = 0;
    job.error = "";
    revokeJobUrl(job);
    render();
  }

  function revokeJobUrl(job) {
    if (job.outputUrl) {
      URL.revokeObjectURL(job.outputUrl);
    }
    job.outputUrl = "";
    job.outputBlob = null;
  }

  function handleQueueClick(event) {
    const button = event.target.closest("button[data-action]");
    if (!button) return;
    const job = state.jobs.find((item) => String(item.id) === button.dataset.id);
    if (button.dataset.action === "download") downloadJob(job);
    if (button.dataset.action === "remove") removeJob(job);
    if (button.dataset.action === "retry") retryJob(job);
  }

  function handleQueueChange(event) {
    const select = event.target.closest("select[data-setting]");
    if (!select || state.isConverting) return;
    const job = state.jobs.find((item) => String(item.id) === select.dataset.id);
    if (!job) return;
    applySettingsToJob(job, {
      ...job.settings,
      [select.dataset.setting]: select.value
    });
    refreshOutputNames();
    setGlobalStatus(`已更新 ${job.file.name} 的输出设置。`);
    render();
  }

  function render() {
    renderTargetSpec();
    renderSummary();
    renderQueue();
    updateButtons();
  }

  function renderTargetSpec() {
    elements.targetSampleRate.textContent = getSampleRateConfig(state.globalSettings.sampleRate).label;
    elements.targetChannel.textContent = getChannelConfig(state.globalSettings.channelMode).label;
    elements.targetFormat.textContent = getFormatConfig(state.globalSettings.format).label;
  }

  function renderSummary() {
    const totalSize = state.jobs.reduce((sum, job) => sum + job.file.size, 0);
    const doneCount = state.jobs.filter((job) => job.status === "done").length;
    const errorCount = state.jobs.filter((job) => job.status === "error").length;
    const pendingCount = state.jobs.filter((job) => job.status === "pending").length;

    elements.summaryCount.textContent = `${state.jobs.length} 个文件`;
    elements.summarySize.textContent = formatBytes(totalSize);

    if (!state.jobs.length) {
      elements.queueProgress.textContent = "等待文件";
    } else if (state.isConverting) {
      elements.queueProgress.textContent = `已完成 ${doneCount}/${state.jobs.length}`;
    } else if (errorCount) {
      elements.queueProgress.textContent = `${doneCount} 完成，${errorCount} 失败`;
    } else if (pendingCount) {
      elements.queueProgress.textContent = `${pendingCount} 个待转换`;
    } else {
      elements.queueProgress.textContent = "全部完成";
    }
  }

  function renderQueue() {
    elements.emptyState.hidden = Boolean(state.jobs.length);
    elements.queueList.innerHTML = state.jobs.map(renderJobMarkup).join("");
  }

  function renderJob(job) {
    const node = elements.queueList.querySelector(`[data-job-id="${job.id}"]`);
    if (!node) {
      renderQueue();
      return;
    }
    node.outerHTML = renderJobMarkup(job);
    renderSummary();
    updateButtons();
  }

  function renderOptions(options, selectedValue) {
    return Object.entries(options)
      .map(([value, config]) => {
        const selected = value === selectedValue ? "selected" : "";
        return `<option value="${escapeHtml(value)}" ${selected}>${escapeHtml(config.label)}</option>`;
      })
      .join("");
  }

  function renderJobMarkup(job) {
    const canDownload = job.status === "done" && job.outputUrl;
    const canRetry = job.status === "error" && !state.isConverting;
    const canRemove = state.activeJob !== job && !state.isConverting;
    const message = job.error || (job.status === "pending" ? "等待转换" : "");
    const settings = normalizeSettings(job.settings);
    const settingsDisabled = state.isConverting ? "disabled" : "";

    return `
      <li class="queue-item" data-job-id="${job.id}">
        <div class="file-main">
          <div class="file-name">${escapeHtml(job.file.name)}</div>
          <div class="file-meta">
            <span>${escapeHtml(formatBytes(job.file.size))}</span>
            <span>${escapeHtml(job.outputName)}</span>
            <span>${escapeHtml(describeSettings(settings))}</span>
            <span class="status-badge status-${escapeHtml(job.status)}">${escapeHtml(statusText[job.status])}</span>
          </div>
          <div class="inline-settings" aria-label="${escapeHtml(job.file.name)} 的输出设置">
            <label class="field">
              <span>采样率</span>
              <select data-setting="sampleRate" data-id="${job.id}" ${settingsDisabled}>
                ${renderOptions(SAMPLE_RATES, settings.sampleRate)}
              </select>
            </label>
            <label class="field">
              <span>声道</span>
              <select data-setting="channelMode" data-id="${job.id}" ${settingsDisabled}>
                ${renderOptions(CHANNEL_MODES, settings.channelMode)}
              </select>
            </label>
            <label class="field">
              <span>格式</span>
              <select data-setting="format" data-id="${job.id}" ${settingsDisabled}>
                ${renderOptions(OUTPUT_FORMATS, settings.format)}
              </select>
            </label>
          </div>
          <div class="progress-track" aria-hidden="true">
            <div class="progress-fill" style="width: ${Math.max(0, Math.min(100, job.progress))}%"></div>
          </div>
          <div class="file-message">${escapeHtml(message)}</div>
        </div>
        <div class="file-actions">
          <button class="mini-button download" type="button" data-action="download" data-id="${job.id}" ${canDownload ? "" : "disabled"}>下载</button>
          <button class="mini-button retry" type="button" data-action="retry" data-id="${job.id}" ${canRetry ? "" : "disabled"}>重试</button>
          <button class="mini-button" type="button" data-action="remove" data-id="${job.id}" ${canRemove ? "" : "disabled"}>移除</button>
        </div>
      </li>
    `;
  }

  function updateButtons() {
    const hasJobs = state.jobs.length > 0;
    const hasConvertibleJobs = state.jobs.some((job) => job.status === "pending" || job.status === "error");
    const hasCompletedJobs = state.jobs.some((job) => job.status === "done" && job.outputBlob);
    elements.applySettings.disabled = !hasJobs || state.isConverting;
    elements.convertAll.disabled = !hasConvertibleJobs || state.isConverting || state.isLoadingEngine;
    elements.downloadAll.disabled = !hasCompletedJobs || state.isConverting || state.isZipping;
    elements.clearAll.disabled = !hasJobs || state.isConverting;
    elements.globalSampleRate.disabled = state.isConverting;
    elements.globalChannelMode.disabled = state.isConverting;
    elements.globalFormat.disabled = state.isConverting;
  }

  function setGlobalStatus(message) {
    elements.globalStatus.textContent = message;
  }

  function getErrorMessage(error) {
    if (!error) return "未知错误";
    if (typeof error === "string") return error;
    if (error.message) return error.message;
    return String(error);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})(typeof window !== "undefined" ? window : globalThis);
