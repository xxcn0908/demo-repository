const assert = require("node:assert/strict");
const utils = require("../app.js");

function test(name, fn) {
  try {
    fn();
    console.log(`PASS ${name}`);
  } catch (error) {
    console.error(`FAIL ${name}`);
    console.error(error);
    process.exitCode = 1;
  }
}

test("makeOutputName removes the final extension and appends 16k wav", () => {
  assert.equal(utils.makeOutputName("lesson.audio.final.mp3"), "lesson.audio.final_16k_mono.wav");
});

test("makeOutputName trims unsafe filename characters", () => {
  assert.equal(utils.makeOutputName("  weird/name?.m4a "), "weird_name__16k_mono.wav");
});

test("makeUniqueName suffixes duplicate output names", () => {
  const used = new Set(["clip_16k_mono.wav", "clip_16k_mono-2.wav"]);
  assert.equal(utils.makeUniqueName("clip_16k_mono.wav", used), "clip_16k_mono-3.wav");
});

test("isAudioFile accepts audio MIME types", () => {
  assert.equal(utils.isAudioFile({ name: "recording.bin", type: "audio/webm" }), true);
});

test("isAudioFile accepts common audio extensions when MIME type is missing", () => {
  assert.equal(utils.isAudioFile({ name: "voice.M4A", type: "" }), true);
});

test("isAudioFile rejects non-audio files", () => {
  assert.equal(utils.isAudioFile({ name: "notes.pdf", type: "application/pdf" }), false);
});

test("formatBytes renders compact file sizes", () => {
  assert.equal(utils.formatBytes(1536), "1.5 KB");
  assert.equal(utils.formatBytes(1048576), "1 MB");
});

test("makeOutputName reflects custom sample rate channel and format", () => {
  const settings = { sampleRate: "44100", channelMode: "stereo", format: "mp3" };
  assert.equal(utils.makeOutputName("lesson.wav", settings), "lesson_44k_stereo.mp3");
});

test("makeOutputName reflects keep channel mode and opus format", () => {
  const settings = { sampleRate: "48000", channelMode: "keep", format: "opus" };
  assert.equal(utils.makeOutputName("voice.m4a", settings), "voice_48k_keep.opus.ogg");
});

test("getFormatConfig returns extension and MIME type for m4a", () => {
  const config = utils.getFormatConfig("m4a");
  assert.equal(config.extension, "m4a");
  assert.equal(config.mimeType, "audio/mp4");
});

test("buildFFmpegArgs builds WAV arguments with sample rate and mono channel", () => {
  const args = utils.buildFFmpegArgs("input.mp3", "output.wav", {
    sampleRate: "16000",
    channelMode: "mono",
    format: "wav"
  });
  assert.deepEqual(args, [
    "-hide_banner",
    "-i",
    "input.mp3",
    "-vn",
    "-ac",
    "1",
    "-ar",
    "16000",
    "-c:a",
    "pcm_s16le",
    "output.wav"
  ]);
});

test("buildFFmpegArgs omits channel argument when keeping source channels", () => {
  const args = utils.buildFFmpegArgs("input.wav", "output.flac", {
    sampleRate: "48000",
    channelMode: "keep",
    format: "flac"
  });
  assert.equal(args.includes("-ac"), false);
  assert.deepEqual(args.slice(-5), ["-ar", "48000", "-c:a", "flac", "output.flac"]);
});
